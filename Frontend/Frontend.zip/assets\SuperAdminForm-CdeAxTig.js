import{j as e}from"./index-CJU3mj7f.js";import{B as i}from"./Button-DIU83nro.js";import{I as o}from"./InputField-DAX_ptrf.js";import{U as p}from"./user-round-CHB8DvEG.js";import{M as n}from"./mail-DmSY5EWS.js";import{P as d}from"./phone-B4OHvdS9.js";import{L as c}from"./lock-Da_7ae8D.js";import{c as t}from"./Sidebar-DH4Z0IWw.js";const P=({formData:s,onChange:l,onSubmit:a,buttonText:r,disabled:m=!1})=>e.jsx("form",{className:`
        bg-white
        border
        border-slate-100
        rounded-2xl
        w-full
        max-w-[440px]
        p-8
        shadow-sm
        animate-[floatIn_480ms_ease]
      `,onSubmit:a,children:e.jsxs("div",{className:`
          grid
          gap-4
        `,children:[e.jsx(o,{label:"Name",name:"name",value:s.name||"",placeholder:"User name",icon:p,onChange:l}),e.jsx(o,{label:"Email",name:"email",type:"email",value:s.email||"",placeholder:"user@company.com",icon:n,onChange:l}),e.jsx(o,{label:"Phone",name:"phone",value:s.phone||"",placeholder:"Phone number",icon:d,onChange:l}),"password"in s&&e.jsx(o,{label:"Password",name:"password",type:"password",value:s.password||"",placeholder:"Password",icon:c,onChange:l}),e.jsx(o,{label:"Role",name:"role",value:s.role||"",placeholder:"admin",icon:t,onChange:l}),e.jsx(i,{type:"submit",disabled:m,children:r})]})});export{P as S};
