import{a as u,r as g,u as x,b as f,j as e,L as b,f as p,g as c,l as j,i as w}from"./index-CJU3mj7f.js";import{B as v}from"./Button-DIU83nro.js";import{E as y}from"./Error-DNOq-vDq.js";import{I as n}from"./InputField-DAX_ptrf.js";import{U as C}from"./user-round-CHB8DvEG.js";import{M as R}from"./mail-DmSY5EWS.js";import{P as E}from"./phone-B4OHvdS9.js";import{L as N}from"./lock-Da_7ae8D.js";import{U as P}from"./user-plus-BMc08RSM.js";const S=()=>{const{loading:a,error:l}=u(t=>t.user),[s,r]=g.useState({name:"",email:"",phone:"",password:""});return{formData:s,loading:a,error:l,handleChange:t=>{const{name:i,value:m}=t.target;r({...s,[i]:m})}}},U=()=>{const a=x(),l=f(),{formData:s,loading:r,error:d,handleChange:t}=S(),i=async m=>{m.preventDefault(),a(p(!0)),a(c(""));try{const o=await fetch(j,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(s)}),h=await o.json();if(!o.ok){a(c(h.message||"Registration failed"));return}a(w(h)),l("/dashboard")}catch(o){a(c(o.message))}finally{a(p(!1))}};return e.jsxs("form",{className:`
        bg-white
        border
        border-slate-100
        rounded-2xl
        w-full
        max-w-[440px]
        p-8
        shadow-md
        animate-[floatIn_480ms_ease]
      `,onSubmit:i,children:[e.jsx("h1",{className:`
          mb-2
          mt-0
          text-2xl
          font-extrabold
          tracking-tight
          text-slate-900
        `,children:"Create Admin"}),e.jsx("p",{className:`
          mb-7
          mt-0
          text-xs
          leading-normal
          text-slate-400
        `,children:"Register a secure enterprise account."}),e.jsxs("div",{className:`
          grid
          gap-4
        `,children:[e.jsx(n,{label:"Name",name:"name",value:s.name,placeholder:"Full name",icon:C,onChange:t}),e.jsx(n,{label:"Email",name:"email",type:"email",value:s.email,placeholder:"admin@company.com",icon:R,onChange:t}),e.jsx(n,{label:"Phone",name:"phone",value:s.phone,placeholder:"Phone number",icon:E,onChange:t}),e.jsx(n,{label:"Password",name:"password",type:"password",value:s.password,placeholder:"Create password",icon:N,onChange:t}),e.jsx(y,{message:d}),e.jsx(v,{icon:P,type:"submit",disabled:r,children:r?"Creating":"Register"}),e.jsx(b,{to:"/",className:`
            text-sm
            text-blue-400
            hover:text-blue-300
            transition-colors
            duration-200
            text-center
            mt-2
            block
          `,children:"Already have an account?"})]})]})},M=()=>e.jsx("main",{className:`
        grid
        min-h-screen
        place-items-center
        p-6
        bg-slate-50
      `,children:e.jsx(U,{})});export{M as default};
