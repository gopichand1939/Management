import{c as E,a as F,r as u,u as S,b as C,j as e,m as j,L as P,f as y,g as p,h as L,i as O,k as R}from"./index-CJU3mj7f.js";import{E as M}from"./Error-DNOq-vDq.js";import{U as D}from"./user-CymnUtUu.js";import{L as U}from"./lock-Da_7ae8D.js";import{E as _}from"./eye-BAiNRu9b.js";import{A as T}from"./arrow-right-szpmKnwp.js";/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const z=E("EyeOff",[["path",{d:"M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49",key:"ct8e1f"}],["path",{d:"M14.084 14.158a3 3 0 0 1-4.242-4.242",key:"151rxh"}],["path",{d:"M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143",key:"13bj9a"}],["path",{d:"m2 2 20 20",key:"1ooewy"}]]),G=()=>{const{loading:i,error:h}=F(o=>o.user),[l,x]=u.useState({email:"",password:""});return{formData:l,loading:i,error:h,handleChange:o=>{const{name:r,value:d}=o.target;x({...l,[r]:d})}}},I="/assets/login-image-blr-stay-DfOlj_F-.png",W=()=>{const i=S(),h=C(),[l,x]=u.useState(!1),[w,o]=u.useState(!1),{formData:r,loading:d,error:v,handleChange:b}=G();u.useEffect(()=>{navigator.geolocation&&navigator.geolocation.getCurrentPosition(()=>{},c=>console.warn("Proactive geolocation prompt status:",c.message),{enableHighAccuracy:!1,timeout:8e3,maximumAge:6e4})},[]);const k=async c=>{c.preventDefault(),i(y(!0)),i(p(""));let m={latitude:null,longitude:null};try{m=await new Promise(t=>{if(!navigator.geolocation)return t({latitude:null,longitude:null});navigator.geolocation.getCurrentPosition(s=>{t({latitude:s.coords.latitude,longitude:s.coords.longitude})},async s=>{console.warn("Geolocation query error or denied. Falling back to IP Geolocation:",s.message);try{const n=await(await fetch("https://ipapi.co/json/")).json();t({latitude:n.latitude||null,longitude:n.longitude||null})}catch(a){console.warn("IP Geolocation lookup fallback failed:",a),t({latitude:null,longitude:null})}},{enableHighAccuracy:!1,timeout:8e3,maximumAge:6e4})})}catch(t){console.warn("Geolocation fetch error:",t)}const N=/Mobi|Android|iPhone|iPad/i.test(navigator.userAgent)?"App":"Web",B=()=>{const t=navigator.userAgent;let s="Unknown Browser",a="Unknown OS",n="";if(t.includes("Firefox")?s="Firefox":t.includes("SamsungBrowser")?s="Samsung Browser":t.includes("Opera")||t.includes("OPR")?s="Opera":t.includes("Trident")?s="Internet Explorer":t.includes("Edge")||t.includes("Edg")?s="Edge":t.includes("Chrome")?s="Chrome":t.includes("Safari")&&(s="Safari"),t.includes("Windows NT"))a="Windows";else if(t.includes("Mac OS X"))a="macOS";else if(t.includes("Android")){a="Android";const g=t.match(/Android\s+\d+;\s+([^;)]+)/i);if(g&&g[1]){const f=g[1].trim();!f.includes("Build")&&!f.includes("Version")&&(n=` (${f})`)}}else t.includes("iPhone")?(a="iOS",n=" (iPhone)"):t.includes("iPad")?(a="iOS",n=" (iPad)"):t.includes("Linux")&&(a="Linux");return`${s} on ${a}${n}`},A={...r,latitude:m.latitude,longitude:m.longitude,device_info:B(),platform:N};try{const t=await fetch(L,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(A)}),s=await t.json();if(!t.ok){i(p(s.message||"Login failed"));return}i(O(s)),h(R(s.user),{replace:!0})}catch(t){i(p(t.message))}finally{i(y(!1))}};return e.jsxs("div",{className:"min-h-screen w-full flex flex-col lg:flex-row bg-white overflow-hidden select-none",children:[e.jsx("div",{className:"w-full lg:w-[65%] h-[35vh] lg:h-screen relative overflow-hidden bg-[#0B1F3A] shrink-0",children:e.jsx(j.img,{src:I,alt:"BLR Stay Premium Residence",className:"absolute inset-0 w-full h-full object-cover",initial:{scale:1.05},animate:{scale:1},transition:{duration:1.5,ease:"easeOut"}})}),e.jsxs("div",{className:"w-full lg:w-[35%] min-h-[65vh] lg:min-h-screen flex flex-col justify-between p-8 sm:p-12 md:p-12 xl:p-16 bg-white shrink-0",children:[e.jsx("div",{className:"hidden lg:block h-6"}),e.jsxs(j.div,{initial:{opacity:0,y:15},animate:{opacity:1,y:0},transition:{duration:.6,ease:"easeOut",delay:.15},className:"w-full max-w-md mx-auto flex flex-col justify-center text-left",children:[e.jsxs("div",{className:"flex items-center gap-4 mb-12 justify-start",children:[e.jsxs("svg",{className:"w-14 h-14 shrink-0",viewBox:"0 0 100 100",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("defs",{children:e.jsx("clipPath",{id:"pinClip",children:e.jsx("path",{d:"M50 92 C 50 92 82 66 82 45 C 82 26 68 12 50 12 C 32 12 18 26 18 45 C 18 66 50 92 50 92 Z"})})}),e.jsx("path",{d:"M50 92 C 50 92 82 66 82 45 C 82 26 68 12 50 12 C 32 12 18 26 18 45 C 18 66 50 92 50 92 Z",fill:"#F59E0B"}),e.jsxs("g",{clipPath:"url(#pinClip)",children:[e.jsx("polygon",{points:"10,100 10,48 50,28 90,48 90,100",fill:"#0B1F3A"}),e.jsx("path",{d:"M12 49 L50 29 L88 49",stroke:"white",strokeWidth:"6",strokeLinecap:"round",strokeLinejoin:"round"}),e.jsx("rect",{x:"65",y:"22",width:"6",height:"12",fill:"white"}),e.jsx("rect",{x:"42",y:"50",width:"6",height:"6",fill:"white",rx:"0.5"}),e.jsx("rect",{x:"52",y:"50",width:"6",height:"6",fill:"white",rx:"0.5"}),e.jsx("rect",{x:"42",y:"60",width:"6",height:"6",fill:"white",rx:"0.5"}),e.jsx("rect",{x:"52",y:"60",width:"6",height:"6",fill:"white",rx:"0.5"})]})]}),e.jsx("div",{className:"flex flex-col text-left justify-center",children:e.jsxs("span",{className:"text-3xl xl:text-4xl font-black tracking-tight text-[#0B1F3A] leading-none flex items-center",children:["BLR",e.jsx("span",{className:"text-[#F59E0B] ml-1",children:"STAY"})]})})]}),e.jsx("h1",{className:"text-3xl xl:text-4xl font-black tracking-tight text-[#0B1F3A] mb-2",children:"Welcome Back"}),e.jsx("p",{className:"text-xs font-semibold text-slate-400 mb-8",children:"Sign in to continue to your dashboard"}),e.jsxs("form",{onSubmit:k,className:"grid gap-5",children:[e.jsxs("div",{className:"grid gap-2",children:[e.jsx("label",{htmlFor:"email",className:"text-xs font-black text-[#0B1F3A] tracking-wide",children:"Username"}),e.jsxs("div",{className:`
                  flex
                  h-12
                  items-center
                  gap-3
                  rounded-xl
                  border
                  border-slate-200/80
                  px-3.5
                  text-slate-400
                  transition-all
                  duration-200
                  group
                  focus-within:border-[#F59E0B]
                  focus-within:ring-4
                  focus-within:ring-[#F59E0B]/10
                  bg-white
                `,children:[e.jsx(D,{size:18,className:"text-slate-450 shrink-0 group-focus-within:text-[#F59E0B] transition-colors duration-200"}),e.jsx("input",{id:"email",name:"email",type:"email",value:r.email,placeholder:"Enter your username",onChange:b,className:"w-full border-0 bg-transparent text-slate-800 outline-none placeholder:text-slate-300 text-sm font-semibold",required:!0})]})]}),e.jsxs("div",{className:"grid gap-2",children:[e.jsx("label",{htmlFor:"password",className:"text-xs font-black text-[#0B1F3A] tracking-wide",children:"Password"}),e.jsxs("div",{className:`
                  flex
                  h-12
                  items-center
                  gap-3
                  rounded-xl
                  border
                  border-slate-200/80
                  px-3.5
                  text-slate-400
                  transition-all
                  duration-200
                  group
                  focus-within:border-[#F59E0B]
                  focus-within:ring-4
                  focus-within:ring-[#F59E0B]/10
                  bg-white
                `,children:[e.jsx(U,{size:18,className:"text-slate-450 shrink-0 group-focus-within:text-[#F59E0B] transition-colors duration-200"}),e.jsx("input",{id:"password",name:"password",type:l?"text":"password",value:r.password,placeholder:"Enter your password",onChange:b,className:"w-full border-0 bg-transparent text-slate-800 outline-none placeholder:text-slate-300 text-sm font-semibold",required:!0}),e.jsx("button",{type:"button",onClick:()=>x(!l),className:"text-slate-400 hover:text-slate-650 group-focus-within:text-[#F59E0B] transition-colors shrink-0 mr-1 cursor-pointer",children:l?e.jsx(z,{size:18}):e.jsx(_,{size:18})})]})]}),e.jsxs("div",{className:"flex items-center justify-between text-xs mt-1 font-bold",children:[e.jsxs("label",{className:"flex items-center gap-2.5 cursor-pointer text-slate-500 hover:text-slate-700 transition-colors",children:[e.jsx("input",{type:"checkbox",checked:w,onChange:c=>o(c.target.checked),className:"h-4 w-4 rounded border-slate-350 text-[#0B1F3A] focus:ring-[#0B1F3A]/10"}),e.jsx("span",{children:"Remember Me"})]}),e.jsx("span",{className:"text-blue-500 hover:text-blue-600 cursor-pointer transition-colors",children:"Forgot Password?"})]}),e.jsx(M,{message:v}),e.jsxs("button",{type:"submit",disabled:d,className:`
                w-full
                h-12
                mt-3
                rounded-xl
                bg-gradient-to-r
                from-[#0B1F3A]
                to-[#1a3861]
                hover:from-[#1a3861]
                hover:to-[#0B1F3A]
                active:scale-[0.985]
                text-white
                font-black
                text-sm
                flex
                items-center
                justify-center
                gap-2
                shadow-[0_4px_12px_rgba(11,31,58,0.15)]
                hover:shadow-[0_0_24px_rgba(245,158,11,0.35)]
                transition-all
                duration-300
                cursor-pointer
                disabled:opacity-50
                disabled:cursor-not-allowed
              `,children:[e.jsx(T,{size:16,className:"stroke-[3]"}),d?"Signing in...":"Login"]})]})]}),e.jsxs("div",{className:"mt-8 flex flex-col items-center gap-4",children:[e.jsx(P,{to:"/register",className:"text-xs font-black text-blue-500 hover:text-blue-600 hover:underline transition-all",children:"Create new admin account"}),e.jsx("span",{className:"text-[10px] font-black text-slate-350",children:"© 2026 BLR STAY. All rights reserved."})]})]})]})},V=()=>e.jsx("main",{className:"min-h-screen w-full bg-white",children:e.jsx(W,{})});export{V as default};
