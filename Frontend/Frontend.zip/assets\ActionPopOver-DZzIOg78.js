import{j as e}from"./index-CJU3mj7f.js";import{E as c}from"./eye-BAiNRu9b.js";import{S as m}from"./square-pen-BK-o2alP.js";import{T as u}from"./trash-2-Dm6cy71n.js";const p=({onView:l,onEdit:i,onDelete:o,actions:t})=>{const r=`
    grid
    h-8
    w-8
    cursor-pointer
    place-items-center
    rounded-lg
    border
    border-slate-200
    bg-white
    text-slate-500
    transition-all
    duration-200
    hover:-translate-y-0.5
    hover:border-slate-300
    hover:bg-slate-50
    hover:text-slate-800
    shadow-sm
  `;return t&&Array.isArray(t)?e.jsx("div",{className:"flex gap-1.5",children:t.map((s,n)=>{if(!s)return null;const a=s.icon;return e.jsx("button",{className:`${r} ${s.className||""}`,title:s.label,onClick:s.onClick,children:a?e.jsx(a,{size:14}):null},n)})}):e.jsxs("div",{className:`
        flex
        gap-1.5
      `,children:[l&&e.jsx("button",{className:r,title:"View user",onClick:l,children:e.jsx(c,{size:14})}),i&&e.jsx("button",{className:r,title:"Edit user",onClick:i,children:e.jsx(m,{size:14})}),o&&e.jsx("button",{className:r,title:"Delete user",onClick:o,children:e.jsx(u,{size:14})})]})};export{p as A};
