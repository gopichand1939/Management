import{c as a,u as E,a as R,r,j as e,as as Z,at as D,b as $,au as K,av as S,aw as w,ax as C,ay as Q,w as X,az as Y,T as G,aA as J,aB as ee}from"./index-CJU3mj7f.js";import{U as te}from"./user-plus-BMc08RSM.js";/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ae=a("Activity",[["path",{d:"M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2",key:"169zse"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const se=a("ArrowUpRight",[["path",{d:"M7 7h10v10",key:"1tivn9"}],["path",{d:"M7 17 17 7",key:"1vkiza"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ne=a("BedDouble",[["path",{d:"M2 20v-8a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v8",key:"1k78r4"}],["path",{d:"M4 10V6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v4",key:"fb3tl2"}],["path",{d:"M12 4v6",key:"1dcgq2"}],["path",{d:"M2 18h20",key:"ajqnye"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const re=a("BellRing",[["path",{d:"M10.268 21a2 2 0 0 0 3.464 0",key:"vwvbt9"}],["path",{d:"M22 8c0-2.3-.8-4.3-2-6",key:"5bb3ad"}],["path",{d:"M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326",key:"11g9vi"}],["path",{d:"M4 2C2.8 3.7 2 5.7 2 8",key:"tap9e0"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const le=a("Bell",[["path",{d:"M10.268 21a2 2 0 0 0 3.464 0",key:"vwvbt9"}],["path",{d:"M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326",key:"11g9vi"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const oe=a("Boxes",[["path",{d:"M2.97 12.92A2 2 0 0 0 2 14.63v3.24a2 2 0 0 0 .97 1.71l3 1.8a2 2 0 0 0 2.06 0L12 19v-5.5l-5-3-4.03 2.42Z",key:"lc1i9w"}],["path",{d:"m7 16.5-4.74-2.85",key:"1o9zyk"}],["path",{d:"m7 16.5 5-3",key:"va8pkn"}],["path",{d:"M7 16.5v5.17",key:"jnp8gn"}],["path",{d:"M12 13.5V19l3.97 2.38a2 2 0 0 0 2.06 0l3-1.8a2 2 0 0 0 .97-1.71v-3.24a2 2 0 0 0-.97-1.71L17 10.5l-5 3Z",key:"8zsnat"}],["path",{d:"m17 16.5-5-3",key:"8arw3v"}],["path",{d:"m17 16.5 4.74-2.85",key:"8rfmw"}],["path",{d:"M17 16.5v5.17",key:"k6z78m"}],["path",{d:"M7.97 4.42A2 2 0 0 0 7 6.13v4.37l5 3 5-3V6.13a2 2 0 0 0-.97-1.71l-3-1.8a2 2 0 0 0-2.06 0l-3 1.8Z",key:"1xygjf"}],["path",{d:"M12 8 7.26 5.15",key:"1vbdud"}],["path",{d:"m12 8 4.74-2.85",key:"3rx089"}],["path",{d:"M12 13.5V8",key:"1io7kd"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ce=a("Carrot",[["path",{d:"M2.27 21.7s9.87-3.5 12.73-6.36a4.5 4.5 0 0 0-6.36-6.37C5.77 11.84 2.27 21.7 2.27 21.7zM8.64 14l-2.05-2.04M15.34 15l-2.46-2.46",key:"rfqxbe"}],["path",{d:"M22 9s-1.33-2-3.5-2C16.86 7 15 9 15 9s1.33 2 3.5 2S22 9 22 9z",key:"6b25w4"}],["path",{d:"M15 2s-2 1.33-2 3.5S15 9 15 9s2-1.84 2-3.5C17 3.33 15 2 15 2z",key:"fn65lo"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ie=a("ChartPie",[["path",{d:"M21 12c.552 0 1.005-.449.95-.998a10 10 0 0 0-8.953-8.951c-.55-.055-.998.398-.998.95v8a1 1 0 0 0 1 1z",key:"pzmjnu"}],["path",{d:"M21.21 15.89A10 10 0 1 1 8 2.83",key:"k2fpak"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const de=a("ChefHat",[["path",{d:"M17 21a1 1 0 0 0 1-1v-5.35c0-.457.316-.844.727-1.041a4 4 0 0 0-2.134-7.589 5 5 0 0 0-9.186 0 4 4 0 0 0-2.134 7.588c.411.198.727.585.727 1.041V20a1 1 0 0 0 1 1Z",key:"1qvrer"}],["path",{d:"M6 17h12",key:"1jwigz"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const I=a("ChevronDown",[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const he=a("ClipboardCheck",[["rect",{width:"8",height:"4",x:"8",y:"2",rx:"1",ry:"1",key:"tgr4d6"}],["path",{d:"M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2",key:"116196"}],["path",{d:"m9 14 2 2 4-4",key:"df797q"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const pe=a("Coins",[["circle",{cx:"8",cy:"8",r:"6",key:"3yglwk"}],["path",{d:"M18.09 10.37A6 6 0 1 1 10.34 18",key:"t5s6rm"}],["path",{d:"M7 6h1v4",key:"1obek4"}],["path",{d:"m16.71 13.88.7.71-2.82 2.82",key:"1rbuyh"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const T=a("CookingPot",[["path",{d:"M2 12h20",key:"9i4pu4"}],["path",{d:"M20 12v8a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-8",key:"u0tga0"}],["path",{d:"m4 8 16-4",key:"16g0ng"}],["path",{d:"m8.86 6.78-.45-1.81a2 2 0 0 1 1.45-2.43l1.94-.48a2 2 0 0 1 2.43 1.46l.45 1.8",key:"12cejc"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ye=a("History",[["path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",key:"1357e3"}],["path",{d:"M3 3v5h5",key:"1xhq8a"}],["path",{d:"M12 7v5l4 2",key:"1fdv2h"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ue=a("Layers",[["path",{d:"M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z",key:"zw3jo"}],["path",{d:"M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12",key:"1wduqc"}],["path",{d:"M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17",key:"kqbvx6"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const xe=a("LayoutDashboard",[["rect",{width:"7",height:"9",x:"3",y:"3",rx:"1",key:"10lvy0"}],["rect",{width:"7",height:"5",x:"14",y:"3",rx:"1",key:"16une8"}],["rect",{width:"7",height:"9",x:"14",y:"12",rx:"1",key:"1hutg5"}],["rect",{width:"7",height:"5",x:"3",y:"16",rx:"1",key:"ldoo1y"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ke=a("LogOut",[["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}],["polyline",{points:"16 17 21 12 16 7",key:"1gabdz"}],["line",{x1:"21",x2:"9",y1:"12",y2:"12",key:"1uyos4"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const me=a("Maximize",[["path",{d:"M8 3H5a2 2 0 0 0-2 2v3",key:"1dcmit"}],["path",{d:"M21 8V5a2 2 0 0 0-2-2h-3",key:"1e4gt3"}],["path",{d:"M3 16v3a2 2 0 0 0 2 2h3",key:"wsl5sc"}],["path",{d:"M16 21h3a2 2 0 0 0 2-2v-3",key:"18trek"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const fe=a("Menu",[["line",{x1:"4",x2:"20",y1:"12",y2:"12",key:"1e0a9i"}],["line",{x1:"4",x2:"20",y1:"6",y2:"6",key:"1owob3"}],["line",{x1:"4",x2:"20",y1:"18",y2:"18",key:"yk5zj1"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const be=a("Minimize",[["path",{d:"M8 3v3a2 2 0 0 1-2 2H3",key:"hohbtr"}],["path",{d:"M21 8h-3a2 2 0 0 1-2-2V3",key:"5jw1f3"}],["path",{d:"M3 16h3a2 2 0 0 1 2 2v3",key:"198tvr"}],["path",{d:"M16 21v-3a2 2 0 0 1 2-2h3",key:"ph8mxp"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ge=a("NotebookText",[["path",{d:"M2 6h4",key:"aawbzj"}],["path",{d:"M2 10h4",key:"l0bgd4"}],["path",{d:"M2 14h4",key:"1gsvsf"}],["path",{d:"M2 18h4",key:"1bu2t1"}],["rect",{width:"16",height:"20",x:"4",y:"2",rx:"2",key:"1nb95v"}],["path",{d:"M9.5 8h5",key:"11mslq"}],["path",{d:"M9.5 12H16",key:"ktog6x"}],["path",{d:"M9.5 16H14",key:"p1seyn"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ve=a("QrCode",[["rect",{width:"5",height:"5",x:"3",y:"3",rx:"1",key:"1tu5fj"}],["rect",{width:"5",height:"5",x:"16",y:"3",rx:"1",key:"1v8r4q"}],["rect",{width:"5",height:"5",x:"3",y:"16",rx:"1",key:"1x03jg"}],["path",{d:"M21 16h-3a2 2 0 0 0-2 2v3",key:"177gqh"}],["path",{d:"M21 21v.01",key:"ents32"}],["path",{d:"M12 7v3a2 2 0 0 1-2 2H7",key:"8crl2c"}],["path",{d:"M3 12h.01",key:"nlz23k"}],["path",{d:"M12 3h.01",key:"n36tog"}],["path",{d:"M12 16v.01",key:"133mhm"}],["path",{d:"M16 12h1",key:"1slzba"}],["path",{d:"M21 12v.01",key:"1lwtk9"}],["path",{d:"M12 21v-1",key:"1880an"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Me=a("ReceiptText",[["path",{d:"M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z",key:"q3az6g"}],["path",{d:"M14 8H8",key:"1l3xfs"}],["path",{d:"M16 12H8",key:"1fr5h0"}],["path",{d:"M13 16H8",key:"wsln4y"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const je=a("Scale",[["path",{d:"m16 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z",key:"7g6ntu"}],["path",{d:"m2 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z",key:"ijws7r"}],["path",{d:"M7 21h10",key:"1b0cd5"}],["path",{d:"M12 3v18",key:"108xh3"}],["path",{d:"M3 7h2c2 0 5-1 7-2 2 1 5 2 7 2h2",key:"3gwbw2"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const we=a("Search",[["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}],["path",{d:"m21 21-4.3-4.3",key:"1qie3q"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ce=a("Shield",[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const _e=a("ShoppingCart",[["circle",{cx:"8",cy:"21",r:"1",key:"jimo8o"}],["circle",{cx:"19",cy:"21",r:"1",key:"13723u"}],["path",{d:"M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12",key:"9zh506"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ze=a("SlidersVertical",[["line",{x1:"4",x2:"4",y1:"21",y2:"14",key:"1p332r"}],["line",{x1:"4",x2:"4",y1:"10",y2:"3",key:"gb41h5"}],["line",{x1:"12",x2:"12",y1:"21",y2:"12",key:"hf2csr"}],["line",{x1:"12",x2:"12",y1:"8",y2:"3",key:"1kfi7u"}],["line",{x1:"20",x2:"20",y1:"21",y2:"16",key:"1lhrwl"}],["line",{x1:"20",x2:"20",y1:"12",y2:"3",key:"16vvfq"}],["line",{x1:"2",x2:"6",y1:"14",y2:"14",key:"1uebub"}],["line",{x1:"10",x2:"14",y1:"8",y2:"8",key:"1yglbp"}],["line",{x1:"18",x2:"22",y1:"16",y2:"16",key:"1jxqpz"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ne=a("Sun",[["circle",{cx:"12",cy:"12",r:"4",key:"4exip2"}],["path",{d:"M12 2v2",key:"tus03m"}],["path",{d:"M12 20v2",key:"1lh1kg"}],["path",{d:"m4.93 4.93 1.41 1.41",key:"149t6j"}],["path",{d:"m17.66 17.66 1.41 1.41",key:"ptbguv"}],["path",{d:"M2 12h2",key:"1t8f8n"}],["path",{d:"M20 12h2",key:"1q8mjw"}],["path",{d:"m6.34 17.66-1.41 1.41",key:"1m8zz5"}],["path",{d:"m19.07 4.93-1.41 1.41",key:"1shlcs"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Se=a("Truck",[["path",{d:"M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2",key:"wrbu53"}],["path",{d:"M15 18H9",key:"1lyqi6"}],["path",{d:"M19 18h2a1 1 0 0 0 1-1v-3.65a1 1 0 0 0-.22-.624l-3.48-4.35A1 1 0 0 0 17.52 8H14",key:"lysw3i"}],["circle",{cx:"17",cy:"18",r:"2",key:"332jqn"}],["circle",{cx:"7",cy:"18",r:"2",key:"19iecd"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const q=a("UserCog",[["circle",{cx:"18",cy:"15",r:"3",key:"gjjjvw"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["path",{d:"M10 15H6a4 4 0 0 0-4 4v2",key:"1nfge6"}],["path",{d:"m21.7 16.4-.9-.3",key:"12j9ji"}],["path",{d:"m15.2 13.9-.9-.3",key:"1fdjdi"}],["path",{d:"m16.6 18.7.3-.9",key:"heedtr"}],["path",{d:"m19.1 12.2.3-.9",key:"1af3ki"}],["path",{d:"m19.6 18.7-.4-1",key:"1x9vze"}],["path",{d:"m16.8 12.3-.4-1",key:"vqeiwj"}],["path",{d:"m14.3 16.6 1-.4",key:"1qlj63"}],["path",{d:"m20.7 13.8 1-.4",key:"1v5t8k"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Te=a("UserRoundCog",[["path",{d:"M2 21a8 8 0 0 1 10.434-7.62",key:"1yezr2"}],["circle",{cx:"10",cy:"8",r:"5",key:"o932ke"}],["circle",{cx:"18",cy:"18",r:"3",key:"1xkwt0"}],["path",{d:"m19.5 14.3-.4.9",key:"1eb35c"}],["path",{d:"m16.9 20.8-.4.9",key:"dfjc4z"}],["path",{d:"m21.7 19.5-.9-.4",key:"q4dx6b"}],["path",{d:"m15.2 16.9-.9-.4",key:"1r0w5f"}],["path",{d:"m21.7 16.5-.9.4",key:"1knoei"}],["path",{d:"m15.2 19.1-.9.4",key:"j188fs"}],["path",{d:"m19.5 21.7-.4-.9",key:"1tonu5"}],["path",{d:"m16.9 15.2-.4-.9",key:"699xu"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const A=a("Users",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["path",{d:"M16 3.13a4 4 0 0 1 0 7.75",key:"1da9ce"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const qe=a("UtensilsCrossed",[["path",{d:"m16 2-2.3 2.3a3 3 0 0 0 0 4.2l1.8 1.8a3 3 0 0 0 4.2 0L22 8",key:"n7qcjb"}],["path",{d:"M15 15 3.3 3.3a4.2 4.2 0 0 0 0 6l7.3 7.3c.7.7 2 .7 2.8 0L15 15Zm0 0 7 7",key:"d0u48b"}],["path",{d:"m2.1 21.8 6.4-6.3",key:"yn04lh"}],["path",{d:"m19 5-7 7",key:"194lzd"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ae=a("Wallet",[["path",{d:"M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1",key:"18etb6"}],["path",{d:"M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4",key:"xoc0q4"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Le=a("Warehouse",[["path",{d:"M22 8.35V20a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V8.35A2 2 0 0 1 3.26 6.5l8-3.2a2 2 0 0 1 1.48 0l8 3.2A2 2 0 0 1 22 8.35Z",key:"gksnxg"}],["path",{d:"M6 18h12",key:"9pbo8z"}],["path",{d:"M6 14h12",key:"4cwo0f"}],["rect",{width:"12",height:"12",x:"6",y:"10",key:"apd30q"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const He=a("X",[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]]),Ue=()=>{var k,c;const h=E(),{authUser:n}=R(i=>i.user),[p,m]=r.useState(!!document.fullscreenElement);r.useEffect(()=>{const i=()=>{m(!!document.fullscreenElement)};return document.addEventListener("fullscreenchange",i),()=>{document.removeEventListener("fullscreenchange",i)}},[]);const f=()=>{document.fullscreenElement?document.exitFullscreen().catch(i=>{console.error("Error attempting to exit fullscreen:",i)}):document.documentElement.requestFullscreen().catch(i=>{console.error("Error attempting to enable fullscreen:",i)})};return e.jsx("div",{className:`
        sticky
        top-0
        z-40
        w-full
        shrink-0
        border-b
        border-slate-100
        bg-white/95
        backdrop-blur-xl
        px-6
        py-3
        shadow-sm
      `,children:e.jsxs("div",{className:"flex items-center justify-between gap-6",children:[e.jsxs("div",{className:"flex flex-1 items-center gap-5",children:[e.jsx("button",{onClick:()=>h(Z()),className:"text-slate-500 transition-colors hover:text-slate-900 lg:hidden cursor-pointer",type:"button",children:e.jsx(fe,{size:20})}),e.jsxs("div",{className:"relative w-full max-w-[360px]",children:[e.jsx("span",{className:"absolute inset-y-0 left-4 flex items-center text-slate-400",children:e.jsx(we,{size:16})}),e.jsx("input",{className:`
                h-10
                w-full
                rounded-lg
                border
                border-slate-200
                bg-slate-50
                pl-11
                pr-12
                text-sm
                text-slate-700
                outline-none
                transition-all
                placeholder:text-slate-400
                focus:border-slate-300
                focus:bg-white
                focus:ring-2
                focus:ring-slate-100
              `,placeholder:"Search anything...",type:"text"}),e.jsx("span",{className:"absolute inset-y-0 right-4 flex items-center text-xs font-semibold text-slate-400",children:"Ctrl K"})]})]}),e.jsxs("div",{className:"flex items-center gap-5",children:[e.jsx("button",{className:"text-slate-500 transition-colors hover:text-slate-900 cursor-pointer",type:"button",children:e.jsx(Ne,{size:19})}),e.jsx("button",{onClick:f,className:"text-slate-500 transition-colors hover:text-slate-900 cursor-pointer",type:"button",title:p?"Exit Fullscreen":"Fullscreen",children:p?e.jsx(be,{size:19}):e.jsx(me,{size:19})}),e.jsxs("button",{className:"relative text-slate-500 transition-colors hover:text-slate-900",type:"button",children:[e.jsx(le,{size:19}),e.jsx("span",{className:`
                absolute
                -right-1
                -top-1
                grid
                h-4
                min-w-4
                place-items-center
                rounded-full
                bg-red-500
                px-1
                text-[10px]
                font-bold
                text-white
              `,children:"3"})]}),e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("span",{className:`
                grid
                h-9
                w-9
                place-items-center
                rounded-full
                bg-orange-100
                text-sm
                font-bold
                text-orange-600
              `,children:((c=(k=n==null?void 0:n.name)==null?void 0:k.charAt(0))==null?void 0:c.toUpperCase())||"A"}),e.jsxs("div",{className:"hidden text-left sm:block",children:[e.jsx("p",{className:"m-0 text-sm font-bold leading-5 text-slate-900",children:(n==null?void 0:n.name)||"Admin User"}),e.jsx("p",{className:"m-0 text-xs leading-4 text-slate-400",children:(n==null?void 0:n.email)||"admin@company.com"})]}),e.jsx(I,{size:16,className:"text-slate-400"})]})]})]})})},Ee="/assets/blr-logo-circular-D9ijjkCO.png",Re={dashboard:xe,institutions:X,pg_admin:Te,super_admin:q,user_management:q,tenant_management:A,tenant_onboarding:te,tenant_vacant_beds:ne,tenant_payments:Me,payment_reminders:re,tenant_vacated:A,tenant_history:ye,expense_management:Ae,daily_expenses:pe,meal_type_master:qe,weekly_food_menu:ge,inventory_management:oe,ration_management:T,ration_inventory:T,category_master:ue,item_master:ce,unit_master:je,supplier_master:Se,purchases:_e,current_stock:Le,kitchen_request:de,stock_issue:se,stock_adjustment:ze,stock_audit:he,inventory_dashboard:ie,qr_labels:ve,user_activity:ae},L=18;let g=0,H=!0;const Ie=(h,n)=>{if(!h||!n)return!0;const p=h.getBoundingClientRect(),m=n.getBoundingClientRect();return p.top>=m.top&&p.bottom<=m.bottom},Fe=()=>{const h=E(),n=D(),p=$(),{t:m}=K(),{authUser:f,isSidebarOpen:k}=R(t=>t.user),c=r.useRef(null),i=r.useRef(null),v=r.useMemo(()=>S(f),[f]),[V,_]=r.useState(()=>{let t=window.location.pathname;(t.startsWith("/tenant/profile/")||t.startsWith("/tenant/edit/"))&&(t="/tenant/active");const l=d=>{for(const s of d){const o=C(s);if(o&&o.route_path&&(t===o.route_path||o.route_path!=="/"&&t.startsWith(`${o.route_path}/`)))return s.parent_menu_id||null;if(s.children&&s.children.length>0){const u=l(s.children);if(u)return u}}return null};return l(S(f))||null}),y=r.useMemo(()=>{const t=l=>{for(const d of l){let s=n.pathname;(s.startsWith("/tenant/profile/")||s.startsWith("/tenant/edit/"))&&(s="/tenant/active");const o=C(d);if(o&&o.route_path&&(s===o.route_path||o.route_path!=="/"&&s.startsWith(`${o.route_path}/`)))return d;if(d.children&&d.children.length>0){const u=t(d.children);if(u)return u}}return null};return t(v)},[v,n.pathname]);r.useEffect(()=>{y&&_(y.parent_menu_id||null)},[y]);const B=r.useCallback(t=>{_(l=>l===t?null:t)},[]);r.useEffect(()=>(k?document.body.style.overflow="hidden":document.body.style.overflow="",()=>{document.body.style.overflow=""}),[k]);const U=r.useCallback(t=>{g=t.target.scrollTop,sessionStorage.setItem("sidebarScrollTop",g)},[]);r.useLayoutEffect(()=>{const t=sessionStorage.getItem("sidebarScrollTop"),l=t!==null?parseFloat(t):g;c.current&&(c.current.scrollTop=l)},[]),r.useEffect(()=>{const t=sessionStorage.getItem("sidebarScrollTop"),l=t!==null?parseFloat(t):g;c.current&&(c.current.scrollTop=l)},[]),r.useEffect(()=>{!(sessionStorage.getItem("sidebarClickedMenu")==="true")&&H&&(requestAnimationFrame(()=>{i.current&&c.current&&!Ie(i.current,c.current)&&i.current.scrollIntoView({behavior:"auto",block:"nearest"})}),H=!1),sessionStorage.removeItem("sidebarClickedMenu")},[]);const F=r.useCallback((t,l)=>{var s;t.preventDefault();const d=((s=c.current)==null?void 0:s.scrollTop)||0;g=d,sessionStorage.setItem("sidebarScrollTop",d),sessionStorage.setItem("sidebarClickedMenu","true"),h(w(!1)),p(l.route_path),requestAnimationFrame(()=>{c.current&&(c.current.scrollTop=d)})},[p,h]),P=async()=>{try{const t=localStorage.getItem(G);t&&await fetch(J,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${t}`}})}catch(t){console.warn("Logout activity logging failed:",t)}h(ee()),p("/")},z=(t,l=!1)=>{var N;const{route_path:d,icon_key:s}=C(t),o=m(Q(t),t.menu_name),u=Re[s]||Ce,M=!!((N=t.children)!=null&&N.length),j=M?V===t.menu_id:!1,W=M&&t.children.some(x=>(y==null?void 0:y.menu_id)===x.menu_id);if(M){const x=W;return e.jsxs("div",{className:"flex flex-col gap-1.5",children:[e.jsxs("button",{className:`
              flex
              items-center
              gap-3
              rounded-xl
              px-4
              py-3
              text-sm
              font-semibold
              transition-all
              duration-200
              w-full
              cursor-pointer
              ${x?"border border-slate-800 bg-slate-800/40 text-slate-200":"border border-transparent text-slate-400"}
            `,type:"button",onClick:()=>B(t.menu_id),"aria-expanded":j,children:[e.jsx("span",{className:"flex h-[18px] w-[18px] shrink-0 items-center justify-center",children:e.jsx(u,{size:L,className:x?"text-white":"text-slate-400"})}),e.jsx("span",{className:"flex-1 text-left truncate",children:o}),e.jsx(I,{size:16,className:`transition-transform duration-200 ${j?"rotate-180":""}`})]}),j&&e.jsx("div",{className:"ml-4 flex flex-col gap-1.5 border-l border-slate-800/80 pl-3",children:t.children.map(O=>z(O,!0))})]},t.menu_id)}const b=(y==null?void 0:y.menu_id)===t.menu_id;return e.jsxs(Y,{to:d,onClick:x=>F(x,t),ref:b?x=>{i.current=x}:void 0,"aria-current":b?"page":void 0,className:`
          flex
          items-center
          gap-3
          rounded-xl
          py-3
          text-sm
          font-semibold
          transition-all
          duration-200
          w-full
          ${l?`ml-2 py-2.5 text-[13px] px-4 ${b?"border border-slate-700/60 bg-slate-800 text-white":"border border-transparent text-slate-400"}`:b?"border border-slate-700/60 bg-slate-800 text-white px-4":"border border-transparent text-slate-400 px-4"}
        `,children:[e.jsx("span",{className:"flex h-[18px] w-[18px] shrink-0 items-center justify-center",children:e.jsx(u,{size:L,className:b?"text-white":"text-slate-400"})}),e.jsx("span",{className:"truncate",children:o})]},t.menu_id)};return e.jsxs(e.Fragment,{children:[k&&e.jsx("div",{onClick:()=>h(w(!1)),className:"fixed inset-0 z-40 bg-black/50 backdrop-blur-sm lg:hidden cursor-pointer"}),e.jsxs("aside",{className:`
          sidebar
          fixed inset-y-0 left-0 z-50
          lg:sticky lg:top-0
          w-[270px]
          border-r border-slate-800 bg-[#111827] p-6 shadow-2xl
          flex flex-col
          transition-transform duration-300 ease-in-out
          ${k?"translate-x-0":"-translate-x-full lg:translate-x-0"}
          lg:flex
        `,children:[e.jsxs("div",{className:"mb-10 flex-shrink-0 flex items-center justify-between px-2",children:[e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("img",{src:Ee,alt:"BLR Stay",className:"h-14 w-14 rounded-full object-contain"}),e.jsx("span",{className:"text-xl font-bold tracking-tight text-white",children:"BLR Stay"})]}),e.jsx("button",{onClick:()=>h(w(!1)),className:"text-slate-400 hover:text-white lg:hidden cursor-pointer flex items-center justify-center w-10 h-10 rounded-full hover:bg-slate-800/50",type:"button","aria-label":"Close sidebar",children:e.jsx(He,{size:20})})]}),e.jsx("nav",{ref:c,onScroll:U,className:"sidebar-menu-scroll flex flex-col gap-1.5",children:v.map(t=>z(t))}),e.jsx("div",{className:"flex-shrink-0 mt-auto pt-6 border-t border-slate-800/60",children:e.jsxs("button",{className:`
              flex
              w-full
              items-center
              gap-3
              rounded-xl
              border
              border-red-500/20
              bg-red-500/10
              px-4
              py-3
              text-sm
              font-semibold
              text-red-200
              transition-all
              duration-200
              hover:bg-red-500/20
              hover:text-white
              cursor-pointer
            `,type:"button",onClick:P,children:[e.jsx(ke,{size:18}),e.jsx("span",{children:"Logout"})]})})]})]})};export{ae as A,ne as B,I as C,ye as H,ue as L,Ue as N,Fe as S,Se as T,A as U,Le as W,He as X,se as a,q as b,Ce as c,we as d,Ae as e,ke as f,re as g,qe as h,oe as i,_e as j,je as k,xe as l,he as m,ie as n,ze as o};
