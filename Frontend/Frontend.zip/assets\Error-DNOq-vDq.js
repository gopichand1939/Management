import{j as e}from"./index-CJU3mj7f.js";const o=({message:r})=>r?e.jsx("div",{className:`
        rounded-xl
        border
        border-red-100
        bg-red-50
        p-3.5
        text-red-600
        text-xs
        font-semibold
      `,children:r}):null;export{o as E};
