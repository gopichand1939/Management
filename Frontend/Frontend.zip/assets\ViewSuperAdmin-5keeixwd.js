import{o as x,a as d,j as e}from"./index-CJU3mj7f.js";import{S as l,N as t,c as n}from"./Sidebar-DH4Z0IWw.js";import{S as m}from"./StatusBadge-5_PiBqs4.js";import{U as c}from"./user-round-CHB8DvEG.js";import{M as o}from"./mail-DmSY5EWS.js";import{P as p}from"./phone-B4OHvdS9.js";import"./user-plus-BMc08RSM.js";const v=()=>{const{id:i}=x(),{users:r}=d(a=>a.user),s=r.find(a=>String(a.id)===i);return s?e.jsxs("div",{className:"grid min-h-screen grid-cols-1 bg-slate-50 lg:grid-cols-[270px_minmax(0,1fr)]",children:[e.jsx(l,{}),e.jsxs("div",{className:"flex h-screen min-h-0 flex-col overflow-y-auto overflow-x-hidden",children:[e.jsx(t,{}),e.jsx("main",{className:"flex flex-1 flex-col bg-slate-50 min-h-0",children:e.jsx("div",{className:"flex-1 w-full pt-7 lg:pt-8 pb-8 px-6 md:px-8",children:e.jsxs("div",{className:"max-w-[440px] mx-auto w-full flex flex-col gap-6 md:gap-8",children:[e.jsxs("div",{className:"text-left",children:[e.jsx("h1",{className:"text-2xl font-black text-slate-800 tracking-tight",children:"Super Admin Details"}),e.jsx("p",{className:"text-sm text-slate-500 mt-1",children:"View super admin profile info and active status"})]}),e.jsx("div",{className:`
                  bg-white
                  border
                  border-slate-100
                  rounded-2xl
                  w-full
                  max-w-[440px]
                  p-8
                  shadow-sm
                  animate-[floatIn_480ms_ease]
                `,children:e.jsxs("div",{className:"grid gap-4",children:[e.jsxs("div",{children:[e.jsx("span",{className:"text-xs font-bold text-slate-400 uppercase tracking-wider",children:"Name"}),e.jsxs("p",{className:"text-slate-800 font-extrabold flex items-center gap-2 mt-1",children:[e.jsx(c,{size:16,className:"text-orange-500"}),s.name]})]}),e.jsxs("div",{children:[e.jsx("span",{className:"text-xs font-bold text-slate-400 uppercase tracking-wider",children:"Email"}),e.jsxs("p",{className:"text-slate-600 font-medium flex items-center gap-2 mt-1",children:[e.jsx(o,{size:16,className:"text-slate-400"}),s.email]})]}),e.jsxs("div",{children:[e.jsx("span",{className:"text-xs font-bold text-slate-400 uppercase tracking-wider",children:"Phone"}),e.jsxs("p",{className:"text-slate-600 font-medium flex items-center gap-2 mt-1",children:[e.jsx(p,{size:16,className:"text-slate-400"}),s.phone]})]}),e.jsxs("div",{children:[e.jsx("span",{className:"text-xs font-bold text-slate-400 uppercase tracking-wider",children:"Role"}),e.jsxs("p",{className:"text-slate-600 font-medium flex items-center gap-2 mt-1",children:[e.jsx(n,{size:16,className:"text-slate-400"}),s.role]})]}),e.jsx("div",{className:"mt-2",children:e.jsx(m,{label:s.status})})]})})]})})})]})]}):e.jsxs("div",{className:"grid min-h-screen grid-cols-1 bg-slate-50 lg:grid-cols-[270px_minmax(0,1fr)]",children:[e.jsx(l,{}),e.jsxs("div",{className:"flex h-screen min-h-0 flex-col overflow-y-auto overflow-x-hidden",children:[e.jsx(t,{}),e.jsx("main",{className:"flex flex-1 flex-col bg-slate-50 min-h-0",children:e.jsx("div",{className:"flex-1 w-full pt-7 lg:pt-8 pb-8 px-6 md:px-8",children:e.jsx("div",{className:`
                  max-w-[440px]
                  mx-auto
                  rounded-xl
                  border
                  border-red-100
                  bg-red-50
                  p-4
                  text-red-600
                  text-sm
                  font-semibold
                `,children:"Super admin not found"})})})]})]})};export{v as default};
