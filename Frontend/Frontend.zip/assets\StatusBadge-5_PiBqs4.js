import{j as a}from"./index-CJU3mj7f.js";const i=({label:l,status:o})=>{const s=o!==void 0?o:l!==void 0?l:"active",e=String(s).toLowerCase();let t="border-slate-200 bg-slate-50 text-slate-650",r="bg-slate-400";return e==="active"||e==="approved"||e==="completed"?(t="border-emerald-100 bg-emerald-50 text-emerald-600",r="bg-emerald-500"):e==="pending"?(t="border-amber-100 bg-amber-50 text-amber-600",r="bg-amber-500"):e==="draft"?(t="border-slate-200 bg-slate-50 text-slate-500",r="bg-slate-400"):(e==="rejected"||e==="inactive")&&(t="border-rose-100 bg-rose-50 text-rose-600",r="bg-rose-500"),a.jsxs("span",{className:`
        inline-flex
        items-center
        gap-1.5
        rounded-full
        border
        px-2.5
        py-0.5
        text-xs
        font-semibold
        w-fit
        ${t}
      `,children:[a.jsx("span",{className:`
          w-1.5
          h-1.5
          rounded-full
          ${r}
        `}),a.jsx("span",{children:s.charAt(0).toUpperCase()+s.slice(1)})]})};export{i as S};
