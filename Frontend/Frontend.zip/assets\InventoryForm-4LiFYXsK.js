import{c as N,r as $,j as e}from"./index-CJU3mj7f.js";import{B as z}from"./Button-DIU83nro.js";import{I as a}from"./InputField-DAX_ptrf.js";import{P as Q}from"./package-DZkyJsnM.js";import{T as G}from"./tag-e6NamX1Q.js";import{L as H}from"./Sidebar-DH4Z0IWw.js";import{C as y}from"./clipboard-list-CHG39OHh.js";import{C as K}from"./calendar-days-D0ejSNIG.js";import{I as Z}from"./indian-rupee-zU-9frAa.js";import{S as J}from"./store-Bmo12K_I.js";import{U as W}from"./upload-DH9afhGZ.js";/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const v=N("PackageCheck",[["path",{d:"m16 16 2 2 4-4",key:"gfu2re"}],["path",{d:"M21 10V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l2-1.14",key:"e7tb2h"}],["path",{d:"m7.5 4.27 9 5.15",key:"1c824w"}],["polyline",{points:"3.29 7 12 12 20.71 7",key:"ousv84"}],["line",{x1:"12",x2:"12",y1:"22",y2:"12",key:"a4e8g8"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const X=N("StickyNote",[["path",{d:"M16 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V8Z",key:"qazsjp"}],["path",{d:"M15 3v4a2 2 0 0 0 2 2h4",key:"40519r"}]]),Y=["Furniture","Electronics","Electrical","Bedding","Kitchen","Cleaning","Plumbing","Safety","Other"],D=["Vendor","Local Vendor","Online Purchase","Owner","Maintenance Team","Other"],ee=["New","Good","Average","Damaged","Repair Required","Other"],oe=["New purchase","Replacement item","Regular inventory item"],j=[{id:"Not Required",floor_name:"Not Required"},{id:"Common Area",floor_name:"Common Area"},{id:"Store Room",floor_name:"Store Room"}],te=[{room_number:"Not Required"},{room_number:"Common Area"},{room_number:"Store Room"}],he=({formData:t,onChange:l,onFileChange:i,onSubmit:P,buttonText:k,institutions:w=[],floors:S=[],rooms:O=[],loadingInstitutions:u=!1,loadingFloors:h=!1,loadingRooms:R=!1,disabled:n=!1})=>{var f;const[I,c]=$.useState(!1),L=`
    w-full
    border-0
    bg-transparent
    text-slate-800
    outline-none
    text-sm
  `,b=({label:o,name:r,value:s,options:T,placeholder:U,disabled:B=!1,getOptionLabel:C,getOptionValue:_})=>e.jsxs("div",{className:"grid gap-1.5",children:[e.jsx("label",{htmlFor:r,className:"text-xs font-bold text-slate-500 uppercase tracking-wider",children:o}),e.jsx("div",{className:"flex min-h-[42px] items-center gap-3 rounded-xl border border-slate-200 px-3.5 text-slate-400 transition-all duration-200 focus-within:text-orange-500 focus-within:border-orange-500/50 focus-within:ring-2 focus-within:ring-orange-500/10 bg-white shadow-sm",children:e.jsxs("select",{id:r,name:r,value:s||"",onChange:l,disabled:B,className:L,children:[e.jsx("option",{value:"",children:U}),T.map(m=>e.jsx("option",{value:_(m),children:C(m)},_(m)))]})})]}),p=t.item_photo_file?URL.createObjectURL(t.item_photo_file):((f=t.item_photo)==null?void 0:f.file_url)||"",F=[...te,...O],x=j.map(o=>o.floor_name),g=t.floor_mode==="manual_custom"||!t.floor_id&&t.floor_label&&!x.includes(t.floor_label),M=g?"manual_custom":t.floor_id||(x.includes(t.floor_label)?`manual:${t.floor_label}`:"")||"",q=[...S.map(o=>({label:o.floor_name,value:o.id})),...j.map(o=>({label:o.floor_name,value:`manual:${o.floor_name}`})),{label:"Manual Floor / Place",value:"manual_custom"}],V=g,A=F.map(o=>o.room_number),d=o=>{if(o.preventDefault(),o.stopPropagation(),o.type==="dragenter"||o.type==="dragover"){c(!0);return}o.type==="dragleave"&&c(!1)},E=o=>{var s;o.preventDefault(),o.stopPropagation(),c(!1);const r=(s=o.dataTransfer.files)==null?void 0:s[0];!r||!i||i({target:{files:[r]}})};return e.jsx("form",{className:`
        bg-white
        border
        border-slate-100
        rounded-2xl
        w-full
        max-w-[720px]
        p-8
        shadow-sm
        animate-[floatIn_480ms_ease]
      `,onSubmit:P,children:e.jsxs("div",{className:"grid gap-4 md:grid-cols-2",children:[b({label:"Institution",name:"institution_id",value:t.institution_id,options:w,placeholder:u?"Loading institutions...":"Select institution",disabled:n||u,getOptionLabel:o=>o.institution_name,getOptionValue:o=>o.id}),e.jsx(a,{label:"Item Name",name:"item_name",value:t.item_name||"",placeholder:"Item name",icon:Q,onChange:l}),e.jsx(a,{label:"Category",name:"category",value:t.category||"",placeholder:"Select or type category",icon:G,list:"inventory-category-options",options:Y,onChange:l}),b({label:"Floor",name:"floor_select",value:M,options:q,placeholder:h?"Loading floors...":"Select floor",disabled:n||h||!t.institution_id,getOptionLabel:o=>o.label,getOptionValue:o=>o.value}),V&&e.jsx(a,{label:"Manual Floor / Place",name:"floor_label",value:t.floor_label||"",placeholder:"Type floor or place",icon:H,onChange:l}),e.jsx(a,{label:"Room No",name:"room_no",value:t.room_no||"",placeholder:R?"Loading rooms...":"Select or type room",icon:y,list:"inventory-room-options",options:A,onChange:l}),e.jsx(a,{label:"Quantity",name:"quantity",type:"number",value:t.quantity||"",placeholder:"Quantity",icon:v,onChange:l}),e.jsx(a,{label:"Purchase Date",name:"purchase_date",type:"date",value:t.purchase_date||"",placeholder:"Purchase date",icon:K,onChange:l}),e.jsx(a,{label:"Purchase Price",name:"purchase_price",type:"number",value:t.purchase_price||"",placeholder:"Purchase price",icon:Z,onChange:l}),e.jsx(a,{label:"Supplier Name",name:"supplier_name",value:t.supplier_name||"",placeholder:"Select or type supplier",icon:J,list:"inventory-supplier-options",options:D,onChange:l}),e.jsx(a,{label:"Condition",name:"condition",value:t.condition||"",placeholder:"Select or type condition",icon:v,list:"inventory-condition-options",options:ee,onChange:l}),e.jsxs("div",{className:"grid gap-1.5 md:col-span-2",children:[e.jsx("label",{htmlFor:"item_photo",className:"text-xs font-bold text-slate-500 uppercase tracking-wider",children:"Item Photo"}),e.jsxs("div",{className:`
              flex
              flex-col
              gap-3
              rounded-xl
              border
              border-dashed
              p-4
              transition-all
              duration-200
              ${I?"border-orange-400 bg-orange-50/40":"border-slate-200 bg-slate-50/50"}
            `,onDragEnter:d,onDragOver:d,onDragLeave:d,onDrop:E,children:[p&&e.jsx("img",{src:p,alt:"Inventory item",className:"h-28 w-28 rounded-xl border border-slate-100 object-cover shadow-sm"}),e.jsxs("label",{htmlFor:"item_photo",className:"inline-flex h-10 w-fit cursor-pointer items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white px-4 text-sm font-bold text-slate-700 transition-all hover:bg-slate-100",children:[e.jsx(W,{size:16}),e.jsx("span",{children:p?"Change Photo":"Upload Photo"})]}),e.jsx("p",{className:"text-xs font-semibold text-slate-400",children:"Drag and drop image here, or click upload"}),e.jsx("input",{id:"item_photo",name:"item_photo",type:"file",accept:"image/*",className:"hidden",onChange:i})]})]}),e.jsx(a,{label:"Status",name:"status",value:t.status||"",placeholder:"active",icon:y,onChange:l}),e.jsx(a,{label:"Remarks",name:"remarks",value:t.remarks||"",placeholder:"Select or type remarks",icon:X,list:"inventory-remarks-options",options:oe,onChange:l}),e.jsx("div",{className:"md:col-span-2",children:e.jsx(z,{type:"submit",disabled:n,children:k})})]})})};export{he as I};
