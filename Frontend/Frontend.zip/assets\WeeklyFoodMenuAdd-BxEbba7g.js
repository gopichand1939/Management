import{at as t,j as o,aF as a}from"./index-CJU3mj7f.js";const n=()=>{const e=t();return o.jsx(a,{to:"/expense/weekly-food-menu",replace:!0,state:e.state})};export{n as default};
