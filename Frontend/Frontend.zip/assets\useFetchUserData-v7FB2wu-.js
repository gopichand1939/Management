import{a}from"./index-CJU3mj7f.js";const n=()=>{const{users:e,loading:r,error:s,token:o}=a(t=>t.user);return{users:e,loading:r,error:s,token:o}};export{n as u};
