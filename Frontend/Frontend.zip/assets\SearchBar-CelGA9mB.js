import{j as e}from"./index-CJU3mj7f.js";import{d as a}from"./Sidebar-DH4Z0IWw.js";const n=({value:s,onChange:r,placeholder:t="Search users..."})=>e.jsxs("div",{className:`
        relative
        w-full
        max-w-xs
      `,children:[e.jsx("span",{className:"absolute inset-y-0 left-3 flex items-center text-slate-400",children:e.jsx(a,{size:16})}),e.jsx("input",{type:"search",value:s,placeholder:t,onChange:r,className:`
          w-full
          pl-9
          pr-4
          py-2
          bg-slate-50
          border
          border-slate-200
          rounded-xl
          text-xs
          text-slate-800
          placeholder-slate-400
          outline-none
          focus:bg-white
          focus:border-orange-500/50
          focus:ring-2
          focus:ring-orange-500/10
          transition-all
          duration-150
        `})]});export{n as S};
