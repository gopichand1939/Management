import{c as s,j as e}from"./index-CJU3mj7f.js";/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const r=s("TriangleAlert",[["path",{d:"m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",key:"wmoenq"}],["path",{d:"M12 9v4",key:"juzpu7"}],["path",{d:"M12 17h.01",key:"p32p05"}]]),c=({title:t,subtitle:a})=>e.jsxs("header",{className:`
        flex
        flex-col
        gap-1
        mb-2
      `,children:[e.jsx("h1",{className:`
          text-2xl
          font-extrabold
          tracking-tight
          text-slate-900
        `,children:t}),e.jsx("p",{className:`
          text-sm
          text-slate-500
        `,children:a})]});export{c as H,r as T};
